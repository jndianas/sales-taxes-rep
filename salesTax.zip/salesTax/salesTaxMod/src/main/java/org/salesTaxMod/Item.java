package org.salesTaxMod;
import java.lang.Math;

public class Item {
	
	
	private String _description;
	private double _price;
	private boolean _exempt;
	private boolean _imported;
	
	private final double _importFee = 5.0;
	private final double _tax = 10.0;
	
	
	
	public Item (String description,double price, boolean exempt, boolean imported){
		
		_description = description;
		_price = price;
		_exempt = exempt;
		_imported = imported;
	
	}
	

	public String getItemDescription() {
		return _description;
	}


	public double getItemPrice() {
		return _price;
	}

	
	public boolean getExempt() {
		return _exempt;
	}

	
	public boolean getImported() {
		return _imported;
	}


	//return item's sales taxes percentage
	public double calculateItemSalesTax() {
	
		
		double result = 0.0;
		
		if (_exempt)	
		{
			if (_imported)
				 result = _importFee;
		}	   		
		else 
		{
			result = _tax;
			
			if (_imported)
				 result = result + _importFee;
		}
					
		return result;
	}
	
	// to calculate the Fees amount
	public double calculateFees() {
		
		
		double _tax = calculateItemSalesTax();		
		
		double _t = _tax;
		
		double _p = getItemPrice();
		
		double rounded = 0.0;
		
		
		if(_t != 0.0)
		{
	
		// item tax amount 
		double feeAmount = _p*_t/100;
	
		//data is rounded up by 0.05 step
		rounded = Math.ceil(feeAmount * 20.0) / 20.0;
		}

		return rounded;
	}
	
	//to calculate item's price with taxes
	public double calculateItemPriceWithTax(){
		
		return getItemPrice() +  calculateFees();
	}

	



}
