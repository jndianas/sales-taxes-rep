package org.salesTaxMod;

import java.util.*;



public class BasketFiller {

	
	ArrayList<Basket> basketList = new ArrayList<Basket>();
	ArrayList<Item> itemList1 = new ArrayList<Item>();
	ArrayList<Item> itemList2 = new ArrayList<Item>();
	ArrayList<Item> itemList3 = new ArrayList<Item>();

	
	//it fills three baskets with the input items 
	public ArrayList<Basket> fillBaskets(){

		
	
		itemList1.add(new Item("book",12.49,true, false));
		itemList1.add(new Item("music CD",14.99,false, false));
		itemList1.add(new Item("chocolate bar",0.85,true, false));
			
		Basket basket1 = new Basket(itemList1);			
		basketList.add(basket1);
			
		
		itemList2.add(new Item("imported box of chocolates",10.00,true, true));
		itemList2.add(new Item("imported bottle of perfume",47.50,false, true));
			
		Basket basket2 = new Basket(itemList2);			
		basketList.add(basket2);
		
		
		itemList3.add(new Item("imported bottle of perfume",27.99, false, true));
		itemList3.add(new Item("bottle of perfume",18.99,false, false));
		itemList3.add(new Item("packet of headache pills",9.75,true, false));
		itemList3.add(new Item("box of imported chocolates",11.25,true, true));
			
		Basket basket3 = new Basket(itemList3);			
		basketList.add(basket3);
		
		
	
		
		return basketList;

	}
	
}
