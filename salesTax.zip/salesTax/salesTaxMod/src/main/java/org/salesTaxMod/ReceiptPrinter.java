package org.salesTaxMod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ReceiptPrinter implements IReceiptPrinter {
	
	public ReceiptPrinter() {
		
	}
		
	
	
	public boolean printReceipt(List<Basket> basketList) {
		
		
		boolean result = false;
		
		
		try {
			
			
			for(int i = 1; i<= basketList.size(); i++)
	    	{
	 
	    	
		    ArrayList<Item> list = basketList.get(i-1).getItemList();
			
		    
			Iterator<Item> it = list.iterator();
			
			    int counter = 0;
			    double totalPrice = 0.0;		  
			    double totalFee = 0.0;
			    
			    
			    
			    System.out.println("Output" + i);
				System.out.println(" ");
				
				
				
				while (it.hasNext()) {
					
					counter++;
					
					
					Item ob = it.next();
					double fee = ob.calculateFees();
					totalFee = Math.round((totalFee + fee) * 1e4) / 1e4;
					
					
					double totalObjectPrice = ob.getItemPrice() + fee;
					
					//data is forced to two decimal digits in every SUM
					double roudedTotal = Math.round(totalObjectPrice * 1e4) / 1e4;			
					
					
					System.out.println(ob.getItemDescription() + " : " +  Math.floor(roudedTotal*100) / 100 );
					
					//data is forced to two decimal digits
					totalPrice = Math.round((totalPrice + ob.getItemPrice() + fee) * 1e4) / 1e4;
					
					if(counter == list.size())
					{
						System.out.println("Sales Taxes : " +  Math.floor(totalFee*100) / 100 );
						System.out.println("Total : " +  Math.floor(totalPrice*100) / 100);
						
						System.out.println("************************************************");
					}
			}
	      }
			
		result = true;
			
		} catch (Exception e) {
			
		}
	
		return result;
	}



	}

	
	
