package org.salesTaxMod;

import java.util.ArrayList;

public class Basket{
	
	private ArrayList<Item> _internalItemList = new ArrayList<Item>();
	
	
	public Basket(ArrayList<Item> itemList){
		
		_internalItemList = itemList;
	}
	
	public void addItem(Item item)
	{
		_internalItemList.add(item);
	}
	
	public void removeItem(Item item)
	{
		_internalItemList.remove(item);
		
	}
	
	public ArrayList<Item> getItemList() {
		return _internalItemList;
	}
}
