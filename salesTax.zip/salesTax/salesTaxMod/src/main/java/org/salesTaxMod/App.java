package org.salesTaxMod;


import java.util.ArrayList;
import java.util.Iterator;



public class App 
{
	
	
    public static void main( String[] args ) {
    	
    	//DATA INITIALIZATION   	
    	BasketFiller dataInitializer = new BasketFiller();    	 	
    	ArrayList<Basket> basketList = dataInitializer.fillBaskets();
    	
    	//RECEIPT PRINTING
    	ReceiptPrinter printer = new ReceiptPrinter();   	
    	printer.printReceipt(basketList);
    
    }
}
