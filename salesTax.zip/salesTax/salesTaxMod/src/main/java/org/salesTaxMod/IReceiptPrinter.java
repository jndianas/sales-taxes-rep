package org.salesTaxMod;

import java.util.List;

public interface IReceiptPrinter {

	boolean printReceipt(List<Basket> basketList);
}
